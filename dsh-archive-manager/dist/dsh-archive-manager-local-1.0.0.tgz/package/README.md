# DSH 归档管理

第二个独立插件，参考 [ZCode 官方归档批量删除](https://github.com/zai-org/ZCode/blob/a9fe401eede6e6e5e01be9048679c206fe6f02d9/docs/task/delete-all-archived-tasks.md)。入口为 **设置 → 归档管理**。

## 使用

1. 在 DSH 会话菜单中将不再使用的会话归档。
2. 打开设置中的「归档管理」。可搜索标题、项目路径和会话 ID。
3. 勾选需要处理的会话，点击「删除所选」；或点击「删除全部归档…」。
4. 核对确认框中的准确数量和会话列表，再确认删除。

归档会话只在设置页集中显示。侧边栏固定显示未归档会话，原来的归档筛选选项会隐藏；之前保存的“仅显示已归档”视图自动切回普通视图。分组与排序保持可用。

“删除全部”处理当前本机宿主的所有归档，不受搜索条件、折叠或前 20 条限制。确认框打开后新归档的会话不会加入本次操作。执行时已取消归档、已删除或仍有运行任务的会话跳过；失败项保留并显示原因。

## 删除的含义

与 ZCode 的列表删除语义一致：保存删除标记，让会话从正常列表和归档列表中移除；**会话记录、项目文件和工作目录保留**，不会释放这些记录占用的磁盘空间。

本插件另外提供「已删除」页：恢复后先回到归档，再点击「取消归档」才重新出现在侧边栏。没有永久擦除按钮。

删除标记由 DSH 的独立存储域 `archive_manager_local` 保存。停用或卸载本插件后，列表过滤会解除，保留的会话可能重新出现在 DSH 原生归档列表；重新启用插件会继续应用已保存的删除标记。它是本地列表整理功能，不是数据访问控制。

## 安装

目标版本：**DeepSeek Harness 0.2.2-rc.1**。其他版本尚未验证。

在 DSH「添加插件」对话框的顶部输入框填写：

```text
F:\dsh-youhua\dsh-archive-manager
```

安装源保持默认即可；不要把这个路径填进 npm 自定义源。安装完成后完全退出并重新启动 DSH，然后进入设置。

也可用桌面版自带命令安装打包文件：

```powershell
& 'D:\deepseek\resources\runtime\cli\bin\dsh.cmd' plugin --profile desktop add 'F:\dsh-youhua\dsh-archive-manager\dist\dsh-archive-manager-local-1.0.0.tgz'
```

或运行此目录中的 `install.ps1`。本次开发没有安装到日常 desktop profile，也没有操作用户已有会话；仅在隔离环境用合成会话验证。

## 实现与边界

- 使用 DSH 原生归档集合及取消归档方法，不建立第二份归档事实。
- 独立存储域保存逻辑删除标记，先完成持久化再更新显示。
- 批次确认凭据 5 分钟有效，目标集合固定；同一凭据重复提交返回同一结果。
- 针对 0.2.2-rc.1 的兼容层使用 `workspaceRegistry.enqueueOperation`，将归档复查与标记写入放在同一宿主队列中；使用 `sessionController.listState` 过滤列表与搜索返回值。不会修改 app.asar。
- 客户端锁定 `uiWorkspace.view.setArchivedFilter` 为普通视图，并用该版本的视图菜单样式选择器隐藏归档筛选区。版本升级后需重新验证这两个适配点。
- 删除标记不会改变底层 Token 使用统计。底层检索数据不擦除；原生搜索会过滤已删除命中，但可能因宿主的结果上限返回较少项目。
- 当前仅支持本机回环访问。插件接口要求同源、专用请求头和 JSON 请求；不接入远程项目或自动连接离线宿主。
- 归档管理读取宿主当前会话集合，打开页面和手动刷新时更新；其他窗口发生变化时请刷新。

## 开发与测试

```powershell
npm ci --ignore-scripts
npm test
npm run pack:plugin
```

隔离测试环境（只生成 26 个测试会话，不复制真实聊天）：

```powershell
npm run build
node scripts/setup-sandbox.mjs
$env:DSH_HOME = 'F:\dsh-youhua\dsh-archive-manager\.sandbox\verified-home'
& 'D:\deepseek\resources\runtime\cli\bin\dsh.cmd' web --port 19421 --no-open
```

测试结束后，在当前 PowerShell 中清除测试变量：`Remove-Item Env:DSH_HOME`。不要将测试 profile 当成日常 profile。

源码在 `src/`，构建产物在 `lib/`，安装包及 SHA-256 在 `dist/`，验证记录和截图在 `qa/`。`.sandbox`、`.research`、测试数据和源代码不包含在安装包中。
